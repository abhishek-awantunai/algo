var arr1 = [];
var arr2 = new Array();
var arr3 = new Array(1, 2, "three", 4, "five");
var arr4 = new Array([1, 2, 3, 4, 5]);
var arr5 = new Array(10);

console.log("arr1 ", arr1);
console.log("arr2 ", arr2);
console.log("arr3 ", arr3);
console.log("arr4 ", arr4);
console.log("arr4 ", arr5);
