/**
  Undefined is not allowed in JSON
  Function is not allowed in JSON
 */