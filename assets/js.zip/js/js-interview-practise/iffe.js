(() => {
  console.log("it's a IFFE function");
})();
