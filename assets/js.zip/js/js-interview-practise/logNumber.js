var num = 50;

function logNumber() {
  console.log(num);
  var num = 10;
}

logNumber();
