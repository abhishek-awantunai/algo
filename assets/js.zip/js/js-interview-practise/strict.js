var city = "London";

console.log(city);
console.log(window);

function caaa(a, b, c) {
  console.log(a, b, c);
}

caaa(1, 2, 3);
