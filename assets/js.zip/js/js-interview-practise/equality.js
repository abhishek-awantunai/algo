console.log(7 == "7"); // true
console.log(7 === "7"); // false
console.log(0.5 - 0.4 === 0.1);  // false
console.log(0.5 - 0.4); // 0.1111

console.log(0 == false); // true
console.log(" " == false); // true
console.log("" == false); // true
console.log("            " == false); // true
console.log("a" == false); // false
