console.log(typeof null);
console.log(typeof {});
console.log(typeof []);
console.log(typeof true);
console.log(typeof 1);
console.log(typeof undefined);
console.log(typeof 'undefined');