/**

  ForkJoin - When we want to make parallel API calls we can use this.

  ConcatMap - When we want to make series API calls we can use this. i.e the decendant API calls are dependant on the previous API calls.

  Flatmap and MergeMap are same

  CombineLatest

  SwitchMap

*/