/*

import HttpServiceInterceptor from "./httpServiceInterceptor";
import GlobalErrorHttpServiceInterceptor from "./httpServiceInterceptor";

export const httpInterceptorProviders = [
  {
    provide: HTTP_INTERCEPTORS,
    useClass: HttpServiceInterceptor,
    multi: true,
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: GlobalErrorHttpServiceInterceptor,
    multi: true,
  },
];


*/
