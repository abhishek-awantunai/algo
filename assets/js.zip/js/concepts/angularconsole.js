/*

It is a cross platform desktop application in which you can create projects and perform all the actions like commands, run genrators, install extensions interacting with editor without getting help from terminal.

*/