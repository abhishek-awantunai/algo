/**

It is a method of making the user to land in a specific page without taking them to the home page.
This helps to get indexed in search engine

*/