/*

Authentication :- to authenticate if it is a valid user using Username Password

Authorization :- To authorize if the user has access to this system

JWT - JSON Web Token

It is used for Authorization

*/