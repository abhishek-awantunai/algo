/**

Functions are first class objects

*/