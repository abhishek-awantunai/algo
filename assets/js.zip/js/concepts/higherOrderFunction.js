/*

 A Higher Order Function is a function that takes one or more function as argument.

*/