/**

  ngOnInit() is a lifecycle hook that is called after Angular has finished initializing all data - bound properties of a directive.It is defined as:

  Interface OnInit {
    ngOnInit() : void
  }

*/
