// const setValue = (id, val) => {
//   let el = document.getElementById(id);
//   el.innerText = val;
// };

// let t1 = performance.now();
// setValue("result-1", 'ddd');
// let t2 = performance.now();
// // console.log(t2 - t1 + " seconds elapsed");
