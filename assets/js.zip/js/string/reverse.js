var reverseString = function (s) {
  return s.reverse();
};

// var reverseString = function (s) {
//   let j = 0;
//   for (let i = s.length - 1; i > Math.floor(s.length / 2) - 1; i--) {
//     let temp1 = s[i];
//     let temp2 = s[j];
//     s[i] = temp2;
//     s[j] = temp1;
//     j++;
//   }
//   return s;
// };

