function reverse(str) {
  return str.split('').reverse().join('');
}

console.log(reverse('helloooo how are you'));