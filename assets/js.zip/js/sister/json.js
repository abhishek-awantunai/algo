const obj = {
  a: "sd",
  b: false,
  c: function () { }, // not valid in JSON
  d: [],
  e: {},
  f: undefined, // not valid in JSON
  g: 12,
};
